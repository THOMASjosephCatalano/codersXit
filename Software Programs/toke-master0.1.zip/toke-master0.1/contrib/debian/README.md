
Debian
====================
This directory contains files used to package toke/toke-qt
for Debian-based Linux systems. If you compile toked/toke-qt yourself, there are some useful files here.

## toke: URI support ##


toke-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install toke-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your toke-qt binary to `/usr/bin`
and the `../../share/pixmaps/toke.png` to `/usr/share/pixmaps`

toke-qt.protocol (KDE)

