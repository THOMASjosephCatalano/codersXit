Gitian building
================

This file was moved to [the Toke Core documentation repository](https://github.com/toke-core/docs/blob/master/gitian-building.md) 
